SELECT * FROM todoapp.task;
insert into `todoapp`.`task`(`id`,`completed`,`title`) value(0,0,'task test');
insert into `todoapp`.`task`(`id`,`completed`,`title`) value(52,0,'task tesjt');

INSERT INTO `todoapp`.`task`(`completed`, `title`) VALUES (0, 'task test');


SHOW CREATE TABLE todoapp.task;

ALTER TABLE todoapp.task MODIFY id int AUTO_INCREMENT;

ALTER TABLE todoapp.task MODIFY id int AUTO_INCREMENT;

SELECT * FROM `todoapp`.`task` WHERE `id` = 0;
delete from `todoapp`.`task`;

UPDATE `todoapp`.`task`
SET `completed` = 0, `title` = 'task test'
WHERE `id` = 0;

DELETE FROM `todoapp`.`task` WHERE `id` = 0;
INSERT INTO `todoapp`.`task` (`id`, `completed`, `title`) VALUES (0, 0, 'task test');

SET SQL_SAFE_UPDATES = 0;
DELETE FROM `todoapp`.`task`;
SET SQL_SAFE_UPDATES = 1; -- Re-enable safe update mode

DELETE FROM `todoapp`.`task` WHERE 1=1;