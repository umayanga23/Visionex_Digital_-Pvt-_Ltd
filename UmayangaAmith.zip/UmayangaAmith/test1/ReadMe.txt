Todo Application
This is a simple Todo application built using Spring Boot and Thymeleaf. It allows users to create, delete, and toggle tasks as completed or incomplete.

Features
Add new tasks

Mark tasks as completed

Delete tasks

View all tasks

Prerequisites
Java Development Kit (JDK) 17 or higher

MySQL database

Maven

Setup Instructions
Clone the Repository

bash
Copy
git clone https://github.com/your-repository/todo-app.git
cd todo-app
Set Up MySQL Database

Create a new database named todoapp in MySQL.

Update the application.properties file with your MySQL credentials:

properties

spring.datasource.url=jdbc:mysql://localhost:3306/todoapp
spring.datasource.username=your-username
spring.datasource.password=your-password
Build the Application

mvn clean install
Run the Application


mvn spring-boot:run
The application will start on http://localhost:8070.

Access the Application

Open your web browser and navigate to http://localhost:8070 to use the Todo application.

Project Structure
src/main/java/com/app/todo_app/: Contains the main application and controller classes.

src/main/resources/templates/: Contains Thymeleaf templates for the UI.

src/main/resources/application.properties: Configuration file for database and server settings.

Dependencies
Spring Boot

Spring Data JPA

Thymeleaf

MySQL Driver

Lombok

Contributing
Feel free to fork the repository and submit pull requests. For major changes, please open an issue first to discuss what you would like to change.