function secondLargestNumber(arr) {
    if (arr.length < 2) {
        return "Array must contain at least two numbers.";
    }

    //Ensure that any real number in the array will be greater.
    let first = -Infinity, second = -Infinity;
    
    for (let num of arr) {
        if (num > first) {
            // Update first and second largest numbers
            second = first;
            first = num;
        } else if (num > second && num !== first) {
            // Update second if num is smaller than first but greater than current second
            second = num;
        }
    }
    // Handle case where there's no second largest number
    return second === -Infinity ? "No second largest number found." : second;
}

console.log(secondLargestNumber([2, 5, 8, 12, 3]));