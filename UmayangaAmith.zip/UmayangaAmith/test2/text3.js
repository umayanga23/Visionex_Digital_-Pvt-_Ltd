function reverseString(str) {
    // Convert string to an array
    //  reverse it
    // join it back to a string
    return str.split('').reverse().join('');
}
 //for outout
console.log(reverseString("Jonta")); 