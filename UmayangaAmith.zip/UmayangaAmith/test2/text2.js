function isPalindrome(str) {
    // Removes all characters that are not letters (a-z) or numbers (0-9).
    let cleanedStr = str.toLowerCase().replace(/[^a-z0-9]/g, '');

    //left starts at the beginning of the string.
    //right starts at the end of the string.
    let left = 0, right = cleanedStr.length - 1;

    while (left < right) {
        if (cleanedStr[left] !== cleanedStr[right]) return false;
        left++;
        right--;
    }
    return true;
}

console.log(isPalindrome("madam")); 
console.log(isPalindrome("hello")); 
console.log(isPalindrome("!Madam, I'm Adam!"));